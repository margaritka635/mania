import UIKit

class ActivityIndicatorPresenter {
    static let shared = ActivityIndicatorPresenter()

    private init() {}

    private var spinner: UIActivityIndicatorView?

    func show(in view: UIView) {
        guard spinner == nil else { return }
        
        let spinner = UIActivityIndicatorView(style: .large)
        spinner.center = view.center
        spinner.startAnimating()
        view.addSubview(spinner)

        self.spinner = spinner
    }

    func hide() {
        spinner?.stopAnimating()
        spinner?.removeFromSuperview()
        spinner = nil
    }
}
extension NSNotification.Name {
    static let themeDidChange = NSNotification.Name("themeDidChange")
}
