import UIKit

// Define your Item and Store models
struct Item: Codable {
    var name: String
    var quantity: Int
    var importance: Importance // Make sure this is defined somewhere
}

struct Store: Codable {
    var name: String
    var items: [Item]
}

// Importance enum, assuming it's defined like this
enum Importance: String, Codable {
    case low = "низкая"
    case medium = "средняя"
    case high = "высокая"
}

//class ItemsViewController: UITableViewController {
//    var store: Store!
//    var currentTheme: ThemeProtocol = LightTheme()
//
//    // ... rest of your class implementation
//}

// If DeletedItemsBasket is in a separate file, make sure to import that file or define it in this file
class DeletedItemsBasket {
    static var deletedItems: [Item] = []

    static func delete(item: Item) {
        // Your implementation
    }
}

// Your extension for the VNDocumentCameraViewControllerDelegate
//extension ItemsViewController: VNDocumentCameraViewControllerDelegate {
//    // ... your delegate methods
//}
