import UIKit
import Vision

class ScannerManager {
    static func scanReceipt(completion: @escaping (Result<[String], Error>) -> Void) {
        // Реализация сканирования чека и обработки результатов
    }
}
