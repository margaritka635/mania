import UIKit
extension NSNotification.Name {
    static let themeChanged = NSNotification.Name("themeChanged")
}


class StoreListViewController: UITableViewController {
   

//    struct LightTheme: ThemeProtocol {
//        var backgroundColor: UIColor {
//            return .white // Or whatever your light theme background color is
//        }
//    }
//
//    struct DarkTheme: ThemeProtocol {
//        var backgroundColor: UIColor {
//            return .black // Or whatever your dark theme background color is
//        }
//    }

    var stores: [Store] = []
    var currentTheme: ThemeProtocol = DarkTheme() // Replace with your actual current theme object

    override func viewDidLoad() {
        super.viewDidLoad()
        setupTableView()
        setupNotifications()

        // Инициализируем магазины
        stores.append(Store(name: "Магазин 1", items: [Item(name: "Молоко", quantity: 2, importance: .medium)]))
        stores.append(Store(name: "Магазин 2", items: [Item(name: "Яблоки", quantity: 5, importance: .high)]))
    }

    private func setupTableView() {
        title = "Магазины"
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "StoreCell")
        navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(addNewStore))
        navigationItem.leftBarButtonItem = editButtonItem
    }

    private func setupNotifications() {
        NotificationCenter.default.addObserver(self, selector: #selector(updateTheme), name: NSNotification.Name.themeChanged, object: nil)
    }

    @objc private func updateTheme() {
        view.backgroundColor = currentTheme.backgroundColor
        tableView.reloadData()
    }

    @objc func addNewStore() {
        let alertController = UIAlertController(title: "Новый магазин", message: "Введите название магазина", preferredStyle: .alert)
        alertController.addTextField { textField in
            textField.placeholder = "Название"
        }
        let addAction = UIAlertAction(title: "Добавить", style: .default) { [unowned self] _ in
            if let name = alertController.textFields?.first?.text, !name.isEmpty {
                let newStore = Store(name: name, items: []) // Removed importance from Store
                self.stores.append(newStore)
                self.tableView.reloadData()
            }
        }
        alertController.addAction(addAction)
        alertController.addAction(UIAlertAction(title: "Отмена", style: .cancel))
        present(alertController, animated: true)
    }
    // ... Your existing code ...

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1 // If you have only one section
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return stores.count // Return the number of stores
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "StoreCell", for: indexPath)

        // Configure the cell...
        let store = stores[indexPath.row]
        cell.textLabel?.text = store.name
        // Add more configuration as needed

        return cell
    }
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let selectedStore = stores[indexPath.row]
        let itemsViewController = ItemsViewController() // Инициализируем ItemsViewController
        itemsViewController.store = selectedStore // Передаем выбранный магазин
        // Переход к ItemsViewController
        navigationController?.pushViewController(itemsViewController, animated: true)
    }
//    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//        let selectedStore = stores[indexPath.row]
//        let itemsViewController = ItemsViewController(store: selectedStore)
//        self.navigationController?.pushViewController(itemsViewController, animated: true)
//    }
//    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
//        if segue.identifier == "showItemsSegue",
//           let destinationVC = segue.destination as? ItemsViewController,
//           let indexPath = tableView.indexPathForSelectedRow {
//            destinationVC.store = stores[indexPath.row]
//
//            destinationVC.currentTheme = ThemeManager.currentTheme // Или как вы получаете текущую тему
//        }
//    }
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
}
