import UIKit

class ItemsViewController: UITableViewController {
    var store: Store!
    var stores: [Store] = []
    
    var currentTheme: ThemeProtocol
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = store.name
        setupNavigationBar()
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "ItemCell")
        navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(addNewItem))
        
        // Если контроллер представлен модально, добавляем кнопку "Назад"
        if navigationController?.presentingViewController != nil {
            navigationItem.leftBarButtonItem = UIBarButtonItem(title: "Назад", style: .plain, target: self, action: #selector(dismissSelf))
        }
        
        // Подписываемся на уведомление о смене темы
        NotificationCenter.default.addObserver(self, selector: #selector(applyCurrentTheme), name: .themeDidChange, object: nil)
        
        // Применяем текущую тему
        applyCurrentTheme()
    }
    
    // Метод для применения текущей темы
    @objc func applyCurrentTheme() {
        if currentTheme is LightTheme {
            applyLightTheme()
        } else {
            applyDarkTheme()
        }
    }

    @objc func toggleTheme() {
        currentTheme = currentTheme is LightTheme ? DarkTheme() : LightTheme()
        NotificationCenter.default.post(name: .themeDidChange, object: nil)
    }

    func applyDarkTheme() {
        // Ваши изменения для темной темы
        view.backgroundColor = .darkGray
        tableView.backgroundColor = .black
        tableView.separatorColor = .darkGray
        tableView.reloadData() // Перезагрузите данные, чтобы изменения вступили в силу
    }

    func applyLightTheme() {
        // Ваши изменения для светлой темы
        view.backgroundColor = .white
        tableView.backgroundColor = .white
        tableView.separatorColor = .lightGray
        tableView.reloadData() // Перезагрузите данные, чтобы изменения вступили в силу
    }

    func setupNavigationBar() {
        let themeToggleTitle = currentTheme is LightTheme ? "Темная тема" : "Светлая тема"
        navigationItem.rightBarButtonItem = UIBarButtonItem(title: themeToggleTitle, style: .plain, target: self, action: #selector(toggleTheme))
    }

    @objc func dismissSelf() {
        dismiss(animated: true, completion: nil)
    }
    @objc private func addNewItem() {let alertController = UIAlertController(title: "Новый товар", message: "Введите информацию о товаре", preferredStyle: .alert)
        
        alertController.addTextField { textField in
            textField.placeholder = "Название товара"
        }
        alertController.addTextField { textField in
            textField.placeholder = "Количество"
            textField.keyboardType = .numberPad
        }
        alertController.addTextField { textField in
            textField.placeholder = "Важность (низкая, средняя, высокая)"
        }

        let addAction = UIAlertAction(title: "Добавить", style: .default) { [weak self] _ in
            guard let self = self,
                  let name = alertController.textFields?[0].text,
                  let quantityString = alertController.textFields?[1].text,
                  let quantity = Int(quantityString),
                  let importanceString = alertController.textFields?[2].text,
                  let importance = Importance(rawValue: importanceString),
                  !name.isEmpty else { return }

            let newItem = Item(name: name, quantity: quantity, importance: importance)
            self.store.items.append(newItem)
            self.saveItems() // Сохраняем изменения
            self.tableView.reloadData()
        }

        alertController.addAction(addAction)
        let cancelAction = UIAlertAction(title: "Отмена", style: .cancel)
        alertController.addAction(cancelAction)
        present(alertController, animated: true)
    }

    // Этот метод сохраняет элементы в постоянное хранилище, например в UserDefaults
    func saveItems() {
            let items = store.items
            let encoder = JSONEncoder()
            if let encodedItems = try? encoder.encode(items) {
                UserDefaults.standard.set(encodedItems, forKey: "items")
            }
        }
        
        func loadItems() {
            if let itemsData = UserDefaults.standard.data(forKey: "items"),
               let decodedItems = try? JSONDecoder().decode([Item].self, from: itemsData) {
                store.items = decodedItems
            }
        }
        
        override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
            if editingStyle == .delete {
                // Сохраняем удаленный товар в корзину перед удалением
                DeletedItemsBasket.delete(item: store.items[indexPath.row])
                // Удаление товара из хранилища и интерфейса
                store.items.remove(at: indexPath.row)
                tableView.deleteRows(at: [indexPath], with: .fade)
                saveItems() // Не забудьте сохранить изменения
            }
        }
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1 // If you have only one section
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return stores.count // Return the number of stores
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "StoreCell", for: indexPath)

        // Configure the cell...
        let store = stores[indexPath.row]
        cell.textLabel?.text = store.name
        // Add more configuration as needed

        return cell
    }
        // ...
    }

//    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        return store.items.count
//    }
//
//    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//        let cell = tableView.dequeueReusableCell(withIdentifier: "ItemCell", for: indexPath)
//        let item = store.items[indexPath.row]
//        cell.textLabel?.text = "\(item.name) - \(item.quantity)"
//        cell.detailTextLabel?.text = item.importance.rawValue
//        return cell
//    }
//
//    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
//        if editingStyle == .delete {
//            store.items.remove(at: indexPath.row)
//            tableView.deleteRows(at: [indexPath], with: .fade)
//        }
//    }
