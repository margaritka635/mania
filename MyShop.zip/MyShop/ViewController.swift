//
//  ViewController.swift
//  MyShop
//
//  Created by Маргарита Волгина on 09.02.2024.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

