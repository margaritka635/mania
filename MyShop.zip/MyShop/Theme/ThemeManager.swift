import UIKit

class ThemeManager {
    static let shared = ThemeManager()
    
    var currentTheme: ThemeProtocol = LightTheme()

    func applyTheme(theme: ThemeProtocol) {
        currentTheme = theme
        NotificationCenter.default.post(name: .themeDidChange, object: nil)
    }
}
