//
//  LightTheme.swift
//  MyShop
//
//  Created by Маргарита Волгина on 09.02.2024.
//
//
import UIKit
//
class LightTheme: ThemeProtocol {
    
    var backgroundColor: UIColor { return UIColor(named: "BackgroundColorLight") ?? .white }
    var textColor: UIColor { return UIColor(named: "TextColorDark") ?? .black }
    var acceptColor: UIColor { return UIColor(named: "AcceptColorLight") ?? .blue }
    
}
