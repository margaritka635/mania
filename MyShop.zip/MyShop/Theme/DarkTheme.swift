//
//  DarkTheme.swift
//  MyShop
//
//  Created by Маргарита Волгина on 09.02.2024.
//


import UIKit
//
class DarkTheme: ThemeProtocol {

    var backgroundColor: UIColor { return UIColor(named: "BackgroundColorDark") ?? .black }
    var textColor: UIColor { return UIColor(named: "TextColorLight") ?? .white }
    var acceptColor: UIColor { return UIColor(named: "AcceptColorDark") ?? .green }

}


