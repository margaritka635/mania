import UIKit

class Theme {
    
    static let shared = Theme()

    private init() {}

    private var spinner: UIActivityIndicatorView?

    func show(in view: UIView) {
        guard spinner == nil else { return }
        
        let spinner = UIActivityIndicatorView(style: .large)
        spinner.center = view.center
        spinner.startAnimating()
        view.addSubview(spinner)

        self.spinner = spinner
    }

    func hide() {
        spinner?.stopAnimating()
        spinner?.removeFromSuperview()
        spinner = nil
    }
}
